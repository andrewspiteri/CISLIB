using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using CIS.TestSupport;

if (args.Length != 6) { throw new ArgumentException("Expected native report, input root, new output root, mutant IDs, flat test-overlay root and explicit test filter."); }
string reportPath = Path.GetFullPath(args[0]), inputRoot = Path.GetFullPath(args[1]), output = Path.GetFullPath(args[2]);
if (Directory.Exists(output) || output.StartsWith(inputRoot + Path.DirectorySeparatorChar, StringComparison.Ordinal)) { throw new IOException("Use a new output outside the input root."); }
var selected = args[3].Split(',').ToHashSet(StringComparer.Ordinal);
var seen = new HashSet<string>(StringComparer.Ordinal);
Directory.CreateDirectory(output);
string snapshot = Path.Combine(output, "source");
CopyTree(inputRoot, snapshot);
string language = Path.Combine(snapshot, "implementations/csharp");
const string project = "tests/CIS.Core.UnitTests/CIS.Core.UnitTests.csproj";
string filter = args[5], overlay = Path.GetFullPath(args[4]);
var testPins = Directory.EnumerateFiles(overlay, "*.cs").Order(StringComparer.Ordinal).Select(path =>
{
    string copied = Path.Combine(language, "tests/CIS.Core.UnitTests", Path.GetFileName(path));
    File.Copy(path, copied, overwrite: true);
    return new { source = path, copied, sha256 = Hash(File.ReadAllBytes(copied)) };
}).ToArray();
if (testPins.Length == 0) { throw new InvalidDataException("The explicit test overlay is empty."); }
var environment = new Dictionary<string, string?> { ["CisMutationTesting"] = "true", ["UseSharedCompilation"] = "false", ["MSBUILDDISABLENODEREUSE"] = "1", ["RestoreLockedMode"] = "true" };
var results = new List<object>();
using var report = JsonDocument.Parse(File.ReadAllBytes(reportPath));
ProcessResult sdk = (await Run("sdk", ["--version"], 60, required: true))!;
if (sdk.StandardOutput.Trim() != "10.0.401" || Environment.Version != new Version(10, 0, 12)) { throw new InvalidDataException("Replay toolchain differs from its pins."); }
File.WriteAllText(Path.Combine(output, "input-control.json"), JsonSerializer.Serialize(new
{
    sdk = sdk.StandardOutput.Trim(), runtime = Environment.Version.ToString(),
    os = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
    verifierSha256 = Hash(File.ReadAllBytes(typeof(Program).Assembly.Location)),
    nativeReportSha256 = Hash(File.ReadAllBytes(reportPath)), selectedMutants = selected.Order(StringComparer.Ordinal).ToArray(), filter, testPins
}, new JsonSerializerOptions { WriteIndented = true }));
await Run("baseline-build", ["build", project, "-c", "Release"], 300, required: true);
await Run("baseline", ["test", project, "-c", "Release", "--no-build", "--no-restore", "--filter", filter,
    "--logger", "trx;LogFileName=tests.trx", "--results-directory", Path.Combine(output, "baseline")], 300, required: true);
foreach (var file in report.RootElement.GetProperty("files").EnumerateObject())
{
    var mutants = file.Value.GetProperty("mutants").EnumerateArray().Where(m => selected.Contains(m.GetProperty("id").GetString()!)).ToArray();
    if (mutants.Length == 0) { continue; }
    string relative = "implementations/" + file.Name.Replace('\\', '/').Split("/implementations/", 2)[1];
    string path = Path.Combine(snapshot, relative), source = File.ReadAllText(path);
    byte[] originalBytes = File.ReadAllBytes(path);
    if (source != file.Value.GetProperty("source").GetString()) { throw new InvalidDataException("Source differs: " + relative); }
    foreach (var mutant in mutants)
    {
        string id = mutant.GetProperty("id").GetString()!, directory = Path.Combine(output, id);
        if (!seen.Add(id)) { throw new InvalidDataException("Native mutant ID is not unique."); }
        Directory.CreateDirectory(directory);
        int Position(JsonElement p)
        {
            int offset = 0;
            for (int line = 1; line < p.GetProperty("line").GetInt32(); line++) { offset = source.IndexOf('\n', offset) + 1; if (offset == 0) { throw new InvalidDataException("Invalid source position."); } }
            return offset + p.GetProperty("column").GetInt32() - 1;
        }
        var location = mutant.GetProperty("location");
        int start = Position(location.GetProperty("start")), end = Position(location.GetProperty("end"));
        string replacement = mutant.GetProperty("replacement").GetString()!, changed = source[..start] + replacement + source[end..];
        File.WriteAllText(path, changed, new UTF8Encoding(originalBytes.AsSpan().StartsWith(new byte[] { 0xef, 0xbb, 0xbf })));
        try
        {
            ProcessResult? result = await Run(id, ["test", project, "-c", "Release", "--no-restore", "--filter", filter,
                "--logger", "trx;LogFileName=tests.trx", "--results-directory", directory], 180);
            string trx = Path.Combine(directory, "tests.trx"), disposition;
            if (result is null) { disposition = "Timeout"; }
            else if (File.Exists(trx))
            {
                var counters = XDocument.Load(trx).Descendants().Single(e => e.Name.LocalName == "Counters");
                int total = (int?)counters.Attribute("total") ?? 0, failed = (int?)counters.Attribute("failed") ?? 0;
                if (total == 0 || (int?)counters.Attribute("executed") != total) { throw new InvalidDataException("Empty/skipped replay tests: " + id); }
                disposition = failed > 0 && result.ExitCode != 0 ? "DetectedBySelectedTests" : result.ExitCode == 0 ? "SurvivedSelectedTests" : throw new InvalidDataException("Ambiguous test exit: " + id);
            }
            else if (result.ExitCode != 0 && (result.StandardOutput + result.StandardError).Contains("error CS", StringComparison.Ordinal)) { disposition = "DoesNotCompileAlone"; }
            else { throw new InvalidDataException("Replay failed without a compiler diagnostic or native result: " + id); }
            results.Add(new { id, file = relative, originalStatus = mutant.GetProperty("status").GetString(), disposition,
                originalText = source[start..end], replacement, filter, sourceSha256 = Hash(originalBytes), mutantSha256 = Hash(File.ReadAllBytes(path)) });
            Save(complete: false); Console.WriteLine(id + ": " + disposition);
        }
        finally { File.WriteAllBytes(path, originalBytes); }
    }
}
if (!seen.SetEquals(selected)) { throw new InvalidDataException("Some selected native IDs were absent."); }
await Run("restored", ["test", project, "-c", "Release", "--no-restore", "--filter", filter,
    "--logger", "trx;LogFileName=tests.trx", "--results-directory", Path.Combine(output, "restored")], 300, required: true);
Save(complete: true);

void Save(bool complete)
{
    foreach (var pin in testPins)
    {
        if (Hash(File.ReadAllBytes(pin.source)) != pin.sha256 || Hash(File.ReadAllBytes(pin.copied)) != pin.sha256)
        { throw new InvalidDataException("Test overlay bytes changed during replay."); }
    }
    File.WriteAllText(Path.Combine(output, "results.json"), JsonSerializer.Serialize(new
    { nativeReportSha256 = Hash(File.ReadAllBytes(reportPath)), metricAdjusted = false, complete, testPinsVerified = true, results }, new JsonSerializerOptions { WriteIndented = true }));
}

async Task<ProcessResult?> Run(string name, string[] command, int seconds, bool required = false)
{
    Directory.CreateDirectory(Path.Combine(output, name));
    ProcessResult result;
    try { result = await ProcessRunner.RunAsync("dotnet", command, language, TimeSpan.FromSeconds(seconds), environment, Encoding.UTF8); }
    catch (TimeoutException error) when (!required) { File.WriteAllText(Path.Combine(output, name, "timeout.txt"), error.Message); return null; }
    File.WriteAllBytes(Path.Combine(output, name, "stdout.bin"), result.StandardOutputBytes.ToArray());
    File.WriteAllBytes(Path.Combine(output, name, "stderr.bin"), result.StandardErrorBytes.ToArray());
    File.WriteAllText(Path.Combine(output, name, "process.json"), JsonSerializer.Serialize(new { result.ExitCode, result.ProcessId, command, seconds }));
    if (required && result.ExitCode != 0) { throw new InvalidDataException("Control failed: " + name); }
    if (required && name is "baseline" or "restored")
    {
        XDocument trx = XDocument.Load(Path.Combine(output, name, "tests.trx"));
        var counters = trx.Descendants().Single(e => e.Name.LocalName == "Counters");
        int total = (int?)counters.Attribute("total") ?? 0;
        if (total == 0 || (int?)counters.Attribute("passed") != total || (int?)counters.Attribute("executed") != total ||
            !trx.Descendants().Any(e => e.Name.LocalName == "StdOut" && e.Value.Contains("CIS mutation scheduling: serialized", StringComparison.Ordinal)))
        { throw new InvalidDataException("Baseline/restored tests are empty, failed, skipped or not serialized."); }
    }
    return result;
}
static string Hash(byte[] bytes) => Convert.ToHexStringLower(SHA256.HashData(bytes));
static void CopyTree(string source, string target)
{
    Directory.CreateDirectory(target);
    foreach (string file in Directory.EnumerateFiles(source)) { File.Copy(file, Path.Combine(target, Path.GetFileName(file))); }
    foreach (string child in Directory.EnumerateDirectories(source))
    {
        if (Path.GetFileName(child) is "bin" or "obj" or ".git" or ".artifacts" or "TestResults" || (File.GetAttributes(child) & FileAttributes.ReparsePoint) != 0) { continue; }
        CopyTree(child, Path.Combine(target, Path.GetFileName(child)));
    }
}

using System.Security.Cryptography;
using System.Text.Json;

if (args.Length != 4) { throw new ArgumentException("Expected Windows report, Linux report, current Core source root and new output directory."); }
string sourceRoot = Path.GetFullPath(args[2]), output = Path.GetFullPath(args[3]);
int validatedSourceFiles = 0;
if (Directory.Exists(output)) { throw new IOException("Use a new immutable output directory."); }
var windows = Read(args[0]);
var linux = Read(args[1]);
if (!windows.Keys.ToHashSet(StringComparer.Ordinal).SetEquals(linux.Keys)) { throw new InvalidDataException("Mutant ID membership differs."); }
var pairs = windows.OrderBy(p => int.Parse(p.Key)).Select(p =>
{
    Entry other = linux[p.Key];
    if (p.Value with { Status = "" } != other with { Status = "" }) { throw new InvalidDataException("Cross-lane source/variant identity differs: " + p.Key); }
    return new Pair(p.Value, other.Status);
}).ToArray();
Directory.CreateDirectory(output);
var options = new JsonSerializerOptions { WriteIndented = true };
File.WriteAllText(Path.Combine(output, "summary.json"), JsonSerializer.Serialize(new
{
    scope = "Exact cross-lane source and variant identity comparison; no status, score or exclusion disposition is changed.",
    windowsReportSha256 = Hash(args[0]), linuxReportSha256 = Hash(args[1]), verifierSha256 = Hash(typeof(Program).Assembly.Location),
    sourceFiles = validatedSourceFiles, filesWithMutants = windows.Values.Select(p => p.File).Distinct().Count(), total = pairs.Length, exactVariantIdentityMatches = true,
    windows = Counts(windows.Values), linux = Counts(linux.Values),
    statusPairs = pairs.GroupBy(p => (Windows: p.Variant.Status, Linux: p.LinuxStatus)).OrderBy(g => g.Key.Windows).ThenBy(g => g.Key.Linux)
        .Select(g => new { windows = g.Key.Windows, linux = g.Key.Linux, count = g.Count() }),
    reviewQueuesAreOverlapping = true,
    reviewQueues = new
    {
        survivedOnEitherLane = pairs.Count(p => p.Variant.Status == "Survived" || p.LinuxStatus == "Survived"),
        survivedOnBothLanes = pairs.Count(p => p.Variant.Status == "Survived" && p.LinuxStatus == "Survived"),
        noCoverageOnEitherLane = pairs.Count(p => p.Variant.Status == "NoCoverage" || p.LinuxStatus == "NoCoverage"),
        timeoutOnEitherLane = pairs.Count(p => p.Variant.Status == "Timeout" || p.LinuxStatus == "Timeout"),
        compilerFilteredOnEitherLane = pairs.Count(p => p.Variant.Status == "CompileError" || p.LinuxStatus == "CompileError"),
        ignoredOnEitherLane = pairs.Count(p => p.Variant.Status == "Ignored" || p.LinuxStatus == "Ignored")
    }
}, options));
File.WriteAllText(Path.Combine(output, "catalog.json"), JsonSerializer.Serialize(new
{ metricAdjusted = false, entries = pairs.Where(p => p.Variant.Status != "Killed" || p.LinuxStatus != "Killed") }, options));
Console.WriteLine(File.ReadAllText(Path.Combine(output, "summary.json")));

Dictionary<string, Entry> Read(string reportPath)
{
    using var report = JsonDocument.Parse(File.ReadAllBytes(reportPath));
    var entries = new Dictionary<string, Entry>(StringComparer.Ordinal);
    var files = new HashSet<string>(StringComparer.Ordinal);
    var allowed = new[] { "Killed", "Survived", "NoCoverage", "Timeout", "CompileError", "Ignored" }.ToHashSet(StringComparer.Ordinal);
    foreach (var file in report.RootElement.GetProperty("files").EnumerateObject())
    {
        const string marker = "/src/CIS.Core/";
        string name = file.Name.Replace('\\', '/');
        int index = name.LastIndexOf(marker, StringComparison.Ordinal);
        if (index < 0) { throw new InvalidDataException("Unmapped source."); }
        string relative = name[(index + marker.Length)..], path = Path.GetFullPath(relative, sourceRoot);
        if (!path.StartsWith(Path.TrimEndingDirectorySeparator(sourceRoot) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || !files.Add(relative))
        { throw new InvalidDataException("Duplicate or escaped source."); }
        string source = File.ReadAllText(path);
        if (source != file.Value.GetProperty("source").GetString()) { throw new InvalidDataException("Current source differs: " + relative); }
        var starts = new List<int> { 0 };
        for (int i = 0; i < source.Length; i++) { if (source[i] == '\n') { starts.Add(i + 1); } }
        foreach (var mutant in file.Value.GetProperty("mutants").EnumerateArray())
        {
            var location = mutant.GetProperty("location");
            var start = location.GetProperty("start"); var end = location.GetProperty("end");
            int startLine = start.GetProperty("line").GetInt32(), startColumn = start.GetProperty("column").GetInt32();
            int endLine = end.GetProperty("line").GetInt32(), endColumn = end.GetProperty("column").GetInt32();
            string status = mutant.GetProperty("status").GetString()!, id = mutant.GetProperty("id").GetString()!;
            if (!allowed.Contains(status)) { throw new InvalidDataException("Incomplete/unknown native status."); }
            entries.Add(id, new(id, relative, Hash(path), mutant.GetProperty("mutatorName").GetString()!, startLine, startColumn, endLine, endColumn,
                source[(starts[startLine - 1] + startColumn - 1)..(starts[endLine - 1] + endColumn - 1)], mutant.GetProperty("replacement").GetString()!, status));
        }
    }
    var current = Directory.EnumerateFiles(sourceRoot, "*.cs", SearchOption.AllDirectories)
        .Where(p => !Path.GetRelativePath(sourceRoot, p).Split(Path.DirectorySeparatorChar).Any(part => part is "bin" or "obj"))
        .Select(p => Path.GetRelativePath(sourceRoot, p).Replace('\\', '/')).ToHashSet(StringComparer.Ordinal);
    if (!current.SetEquals(files)) { throw new InvalidDataException("Current/native source membership differs."); }
    validatedSourceFiles = files.Count;
    return entries;
}
static object Counts(IEnumerable<Entry> entries)
{
    var counts = entries.GroupBy(p => p.Status).ToDictionary(g => g.Key, g => g.Count());
    long denominator = new[] { "Killed", "Survived", "NoCoverage", "Timeout" }.Sum(s => (long)counts.GetValueOrDefault(s));
    return new { counts, strictScore = denominator == 0 ? (decimal?)null : 100m * counts.GetValueOrDefault("Killed") / denominator };
}
static string Hash(string path) { using var stream = File.OpenRead(path); return Convert.ToHexStringLower(SHA256.HashData(stream)); }
internal sealed record Entry(string Id, string File, string SourceSha256, string Mutator, int StartLine, int StartColumn, int EndLine, int EndColumn, string Original, string Replacement, string Status);
internal sealed record Pair(Entry Variant, string LinuxStatus);

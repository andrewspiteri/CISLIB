namespace CIS.Logging; public sealed partial class CoreLogger { /// <summary>Qualification-only additive API control.</summary>
 public bool QualificationAddition() => true; }

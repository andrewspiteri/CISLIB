namespace CIS.Logging.Runtime;
// Acquisition owns physical handles only. Inventory validation must precede any append.
internal sealed class FileOutputOwner : IDisposable
{
    private readonly FileStream lease;
    internal string AbsolutePath { get; }
    internal FileStream ActiveFile { get; private set; }
    internal FileGroupInventory? Inventory { get; private set; }
    internal bool ActiveWasCreated { get; }
    internal bool RecoveredPartialSegment { get; private set; }

    private FileOutputOwner(string absolutePath, FileStream lease, FileStream activeFile, bool activeWasCreated)
    {
        AbsolutePath = absolutePath;
        this.lease = lease;
        ActiveFile = activeFile;
        ActiveWasCreated = activeWasCreated;
    }

    internal static FileOutputOwner Initialize(string capturedAbsolutePath) => InitializeCore(capturedAbsolutePath, rejectLostActive: false);
    private static FileOutputOwner InitializeCore(string capturedAbsolutePath, bool rejectLostActive, LogOutputFormat? format = null, int maximumRetainedFiles = LoggingOptions.MaximumFileRetainedFiles, long maximumFileBytes = long.MaxValue)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(capturedAbsolutePath);
        if (!Path.IsPathFullyQualified(capturedAbsolutePath))
        {
            throw new ArgumentException("File output requires a captured absolute path.", nameof(capturedAbsolutePath));
        }

        FileStream? lease = null, active = null;
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(capturedAbsolutePath)!);
            string leasePath = capturedAbsolutePath + ".cis.lock";
            try
            {
                lease = new FileStream(leasePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException)
            {
                throw new CoreLogInitializationException("file", "FileOwnershipUnavailable");
            }

            // A reserved lease is empty and persistent. Never truncate an existing collision.
            if (lease.Length != 0 || !ExcludesSecondHandle(leasePath))
            {
                throw new CoreLogInitializationException("file", "FileOwnershipUnavailable");
            }

            bool recoveredPartial = format is { } selected && FileGroupTransition.Reconcile(capturedAbsolutePath, selected, maximumRetainedFiles, maximumFileBytes);
            bool activeWasCreated = false;
            try
            {
                active = OpenActive(capturedAbsolutePath, FileMode.Open);
            }
            catch (FileNotFoundException)
            {
                if (rejectLostActive && HasExistingInventory(capturedAbsolutePath))
                {
                    throw new CoreLogInitializationException("file", "FileInventoryIncompatible");
                }

                active = OpenActive(capturedAbsolutePath, FileMode.CreateNew);
                activeWasCreated = true;
            }

            var owner = new FileOutputOwner(capturedAbsolutePath, lease, active, activeWasCreated)
            {
                RecoveredPartialSegment = recoveredPartial
            };
            lease = null;
            active = null;
            return owner;
        }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or System.Security.SecurityException or ArgumentException or NotSupportedException)
        {
            throw new CoreLogInitializationException("file", "FileInitializationFailed");
        }
        finally
        {
            try
            {
                active?.Dispose();
            }
            finally
            {
                lease?.Dispose();
            }
        }
    }

    private static bool HasExistingInventory(string path)
    {
        try
        {
            using var existing = new FileStream(path + ".cis.inventory.json", FileMode.Open, FileAccess.Read, FileShare.Read);
            return true;
        }
        catch (FileNotFoundException)
        {
            return false;
        }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or System.Security.SecurityException)
        {
            throw new CoreLogInitializationException("file", "FileInventoryInitializationFailed");
        }
    }

    private static FileStream OpenActive(string path, FileMode mode) => new(path, mode, FileAccess.ReadWrite, FileShare.Read, bufferSize: 1, FileOptions.Asynchronous | FileOptions.SequentialScan);
    internal static FileOutputOwner Initialize(string capturedAbsolutePath, LogOutputFormat format, int maximumRetainedFiles = LoggingOptions.MaximumFileRetainedFiles, long maximumFileBytes = long.MaxValue)
    {
        if (!Enum.IsDefined(format))
        {
            throw new ArgumentOutOfRangeException(nameof(format));
        }

        FileOutputOwner owner = InitializeCore(capturedAbsolutePath, rejectLostActive: true, format, maximumRetainedFiles, maximumFileBytes);
        try
        {
            owner.Inventory = FileGroupInventory.OpenOrCreate(owner, format);
            return owner;
        }
        catch
        {
            owner.Dispose();
            throw;
        }
    }

    internal void Rotate(int maximumRetainedFiles)
    {
        RequireOwnership();
        FileGroupInventory current = Inventory ?? throw new InvalidOperationException("Rotation requires a managed inventory.");
        FileGroupInventory next = current.AfterRotation(AbsolutePath, maximumRetainedFiles);
        string directory = Path.GetDirectoryName(AbsolutePath)!;
        string closedPath = Path.Combine(directory, next.Segments[^2].FileName);
        // Reject a known reserved-name collision before retiring any listed evidence.
        // The non-overwriting move below still protects against later external races.
        if (File.Exists(closedPath) || Directory.Exists(closedPath))
        {
            throw new IOException("Reserved closed segment already exists.");
        }

        CommitTransition(next, maximumRetainedFiles, recovery: false, closedPath);
    }

    internal void RecoverPartialSegment(int maximumRetainedFiles)
    {
        RequireOwnership();
        FileGroupInventory current = Inventory ?? throw new InvalidOperationException("Recovery requires a managed inventory.");
        if (JsonlRecordBoundary.Inspect(this).Status != JsonlBoundaryStatus.Partial)
        {
            throw new InvalidOperationException("Recovery requires a partial final JSONL record.");
        }

        FileGroupInventory next = current.AfterPartialRecovery(AbsolutePath, maximumRetainedFiles);
        string damagedPath = Path.Combine(Path.GetDirectoryName(AbsolutePath)!, next.Segments[^2].FileName);
        if (File.Exists(damagedPath) || Directory.Exists(damagedPath))
        {
            throw new CoreLogInitializationException("file", "FileRecoveryCollision");
        }

        CommitTransition(next, maximumRetainedFiles, recovery: true, damagedPath);
        RecoveredPartialSegment = true;
    }

    private void CommitTransition(FileGroupInventory next, int maximumRetainedFiles, bool recovery, string archivedPath)
    {
        FileGroupTransition intent = FileGroupTransition.Begin(this, next, maximumRetainedFiles, recovery);
        intent.Retire(AbsolutePath);
        // Keep the lease throughout. No incoming record is appended before publication;
        // any interruption is reconciled from the exact durable intent by a later owner.
        ActiveFile.Dispose();
        File.Move(AbsolutePath, archivedPath, overwrite: false);
        next.PublishReplacement(AbsolutePath);
        Inventory = next;
        ActiveFile = OpenActive(AbsolutePath, FileMode.CreateNew);
        FileGroupTransition.Complete(AbsolutePath);
    }

    internal void RequireOwnership()
    {
        if (!lease.CanWrite || !ActiveFile.CanWrite)
        {
            throw new InvalidOperationException("File ownership is not active.");
        }
    }

    private static bool ExcludesSecondHandle(string leasePath)
    {
        try
        {
            using var second = new FileStream(leasePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            return false;
        }
        catch (IOException)
        {
            return true;
        }
    }

    public void Dispose()
    {
        try
        {
            ActiveFile.Dispose();
        }
        finally
        {
            lease.Dispose();
        }
        // Do not unlink the lease: a new inode could bypass an existing Unix owner's lock.
    }
}

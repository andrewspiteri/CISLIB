// WP02-S03 nonshipping, reference-only runtime/result signatures. No implementation.
#nullable enable
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace CIS.Logging;

public enum LogWriteOutcome : int
{
    Accepted = 0,
    PartiallyAccepted = 1,
    Filtered = 2,
    Rejected = 3,
    Stopped = 4,
    InvalidEvent = 5,
}

public enum LogOutputWriteStatus : int
{
    Accepted = 0,
    Filtered = 1,
    QueueFull = 2,
    Faulted = 3,
    Stopped = 4,
}

public enum LogCompletion : int
{
    Completed = 0,
    TimedOut = 1,
    Canceled = 2,
    Failed = 3,
}

public enum LogFrontendCaptureStatus : int { NoBatchCaptured = 0, Captured = 1 }

public sealed class LogStartResult
{
    private LogStartResult() { }
    public extern bool Succeeded { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern string? ErrorCode { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class LogFrontendBatchSnapshot
{
    private LogFrontendBatchSnapshot() { }
    public extern long TargetCount { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Consumed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Evicted { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Abandoned { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Pending { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool IsComplete { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool IsLossless { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public enum LogOutputState : int
{
    Running = 0,
    Faulted = 1,
    Stopping = 2,
    Stopped = 3,
}

public enum CoreLogState : int
{
    Running = 0,
    Stopping = 1,
    Stopped = 2,
}

public enum LogWriterFlushStatus : int
{
    NotRequested = 0,
    Pending = 1,
    Succeeded = 2,
    Failed = 3,
}

public sealed class LogWriteResult
{
    private LogWriteResult() { }
    public extern LogWriteOutcome Outcome { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern IReadOnlyList<LogOutputWriteResult> Outputs { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern string? ErrorCode { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool IsTruncated { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long? IncomingSequence { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class LogIncomingSnapshot
{
    private LogIncomingSnapshot() { }
    public extern long Accepted { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Processed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Failed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Abandoned { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Pending { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long QueueFull { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long RejectedByWriters { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Suppressed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long DuplicateSuppressed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long DuplicateKeyEvictions { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Admitted { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Consumed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Evicted { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Waiting { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long ActivePublishers { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool IsSaturated { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool IsExact { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern string? ErrorCode { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class LogOutputWriteResult
{
    private LogOutputWriteResult() { }
    public extern string OutputName { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogOutputWriteStatus Status { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long? AcceptedSequence { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class LogFlushResult
{
    private LogFlushResult() { }
    public extern LogFrontendBatchSnapshot? FrontendBatch { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogFrontendCaptureStatus FrontendCaptureStatus { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern string? ErrorCode { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogIncomingSnapshot? Incoming { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogCompletion Completion { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool Succeeded { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool LossObserved { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern DateTimeOffset BoundaryCapturedAtUtc { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern DateTimeOffset ObservedAtUtc { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long InvalidEventCount { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long TruncatedEventCount { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern IReadOnlyList<LogOutputDrainResult> Outputs { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class LogStopResult
{
    private LogStopResult() { }
    public extern string? ErrorCode { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogIncomingSnapshot? Incoming { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogCompletion Completion { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool Succeeded { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool LossObserved { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern DateTimeOffset BoundaryCapturedAtUtc { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern DateTimeOffset ObservedAtUtc { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long InvalidEventCount { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long TruncatedEventCount { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern IReadOnlyList<LogOutputDrainResult> Outputs { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class LogOutputDrainResult
{
    private LogOutputDrainResult() { }
    public extern string OutputName { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long AcceptedSequenceBoundary { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Written { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Failed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Abandoned { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Pending { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogWriterFlushStatus WriterFlushStatus { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool WriterFlushSucceeded { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogOutputRejectionSnapshot Rejections { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class LogOutputRejectionSnapshot
{
    private LogOutputRejectionSnapshot() { }
    public extern long Filtered { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long QueueFull { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Unavailable { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class CoreLogDiagnostics
{
    private CoreLogDiagnostics() { }
    public extern LogIncomingSnapshot? Incoming { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern CoreLogState State { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool AdmissionClosed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern DateTimeOffset ObservedAtUtc { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern DateTimeOffset? ShutdownStartedAtUtc { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long InvalidEventCount { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long TruncatedEventCount { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern IReadOnlyList<LogOutputDiagnostics> Outputs { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogStopResult? LastStopResult { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class LogOutputDiagnostics
{
    private LogOutputDiagnostics() { }
    public extern string OutputName { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern LogOutputState State { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long AcceptedSequence { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Filtered { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long AdmissionAttempts { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Accepted { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long QueueFull { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Unavailable { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Written { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Failed { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Abandoned { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Pending { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long InFlight { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern long Buffered { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern string? LastFaultCode { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern DateTimeOffset? LastFaultAtUtc { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern bool RecoveredPartialSegment { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public sealed class CoreLogInitializationException : Exception
{
    private CoreLogInitializationException() { }
    public extern string OutputName { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern string ErrorCode { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

public static class LogErrorCodes
{
    public const string InvalidEventName = "InvalidEventName";
    public const string InvalidMessage = "InvalidMessage";
    public const string InvalidOperationId = "InvalidOperationId";
    public const string InvalidAttributeKey = "InvalidAttributeKey";
    public const string UnsupportedValue = "UnsupportedValue";
    public const string InvalidUnicode = "InvalidUnicode";
    public const string InvalidFactoryResult = "InvalidFactoryResult";
    public const string EnvelopeTooLarge = "EnvelopeTooLarge";
    public const string IncomingQueueFull = "IncomingQueueFull";
    public const string RecursiveProcessing = "RecursiveProcessing";
    public const string ConsoleInitializationFailed = "ConsoleInitializationFailed";
    public const string FileFlushTimerInitializationFailed = "FileFlushTimerInitializationFailed";
    public const string WorkerInitializationFailed = "WorkerInitializationFailed";
    public const string ShutdownTimerCleanupFailed = "ShutdownTimerCleanupFailed";
    public const string OutputInitializationFailed = "OutputInitializationFailed";
    public const string OutputOwnershipUnavailable = "OutputOwnershipUnavailable";
    public const string WriteFailed = "WriteFailed";
    public const string RenderFailed = "RenderFailed";
    public const string RenderTooLarge = "RenderTooLarge";
    public const string FlushFailed = "FlushFailed";
}

public sealed class CoreLogRuntime : IAsyncDisposable
{
    private CoreLogRuntime() { }
    [MethodImpl(MethodImplOptions.InternalCall)]
    public static extern CoreLogRuntime Create();
    [MethodImpl(MethodImplOptions.InternalCall)]
    public static extern CoreLogRuntime Create(IEnumerable<LogWriterRegistration> writers);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public static extern CoreLogRuntime Create(LogProcessingOptions processing, IEnumerable<LogWriterRegistration>? writers = null);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public static extern LogStartResult TryCreate(out CoreLogRuntime? runtime);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public static extern LogStartResult TryCreate(IEnumerable<LogWriterRegistration> writers, out CoreLogRuntime? runtime);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public static extern LogStartResult TryCreate(LogProcessingOptions processing, out CoreLogRuntime? runtime, IEnumerable<LogWriterRegistration>? writers = null);
    public extern Task Completion { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern CoreLogger CreateLogger(string component);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern IDisposable BeginScope(OperationContextData context);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern Task<LogFlushResult> FlushAsync(TimeSpan timeout, CancellationToken cancellationToken);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern Task<LogStopResult> StopAsync(CancellationToken cancellationToken);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern CoreLogDiagnostics GetDiagnostics();
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern ValueTask DisposeAsync();
}

public sealed class CoreLogger
{
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Write(CoreLogLevel level, ref LogInterpolatedStringHandler message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Write(CoreLogLevel level, ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue> values);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Write(CoreLogLevel level, string eventName, ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue>? values = null);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Write(CoreLogLevel level, ref LogInterpolatedStringHandler message, LogEventData context);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Trace(ref LogInterpolatedStringHandler message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Trace(ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue> values);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Trace(string eventName, ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue>? values = null);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Debug(ref LogInterpolatedStringHandler message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Debug(ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue> values);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Debug(string eventName, ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue>? values = null);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Info(ref LogInterpolatedStringHandler message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Info(ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue> values);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Info(string eventName, ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue>? values = null);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Warn(ref LogInterpolatedStringHandler message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Warn(ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue> values);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Warn(string eventName, ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue>? values = null);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Error(ref LogInterpolatedStringHandler message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Error(ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue> values);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Error(string eventName, ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue>? values = null);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Critical(ref LogInterpolatedStringHandler message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Critical(ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue> values);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Critical(string eventName, ref LogInterpolatedStringHandler message, IReadOnlyDictionary<string, LogValue>? values = null);
    private CoreLogger() { }
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern bool IsEnabled(CoreLogLevel level);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Write(CoreLogLevel level, LogEventData data);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult WriteLazy(CoreLogLevel level, Func<LogEventData> factory);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Trace(string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Trace(string eventName, string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Trace(LogEventData data);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult TraceLazy(Func<LogEventData> factory);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Debug(string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Debug(string eventName, string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Debug(LogEventData data);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult DebugLazy(Func<LogEventData> factory);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Info(string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Info(string eventName, string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Info(LogEventData data);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult InfoLazy(Func<LogEventData> factory);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Warn(string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Warn(string eventName, string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Warn(LogEventData data);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult WarnLazy(Func<LogEventData> factory);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Error(string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Error(string eventName, string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Error(LogEventData data);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult ErrorLazy(Func<LogEventData> factory);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Critical(string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Critical(string eventName, string message);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult Critical(LogEventData data);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriteResult CriticalLazy(Func<LogEventData> factory);

}

[System.Runtime.CompilerServices.InterpolatedStringHandler]
public struct LogInterpolatedStringHandler
{
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogInterpolatedStringHandler(int literalLength, int formattedCount);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern void AppendLiteral(string value);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern void AppendFormatted<T>(T value);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern void AppendFormatted<T>(T value, string? format);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern void AppendFormatted<T>(T value, int alignment);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern void AppendFormatted<T>(T value, int alignment, string? format);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern void AppendFormatted(string? value, int alignment = 0, string? format = null);
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern void AppendFormatted(ReadOnlySpan<char> value, int alignment = 0, string? format = null);
}

public interface ILogWriter : IAsyncDisposable
{
    ValueTask WriteAsync(string jsonLine, CancellationToken cancellationToken);
    ValueTask FlushAsync(CancellationToken cancellationToken);
}
public sealed class LogWriterRegistration
{
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogWriterRegistration(string name, ILogWriter writer, CoreLogLevel level = CoreLogLevel.Information, bool ownsWriter = false);
    public extern string Name { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern ILogWriter Writer { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public CoreLogLevel Level { get; }
    public bool OwnsWriter { get; }
}
public sealed class LogProcessingOptions
{
    public IReadOnlyList<Func<LogProcessingEvent, LogEventChanges>> Interceptors { get; set; } = [];
    public Func<LogProcessingEvent, bool>? Filter { get; set; }
    public Func<string, LogProcessingEvent, bool>? Route { get; set; }
    public LogDuplicateSuppression? DuplicateSuppression { get; set; }
}
public sealed class LogDuplicateSuppression
{
    [MethodImpl(MethodImplOptions.InternalCall)]
    public extern LogDuplicateSuppression(Func<LogProcessingEvent, string?> key, TimeSpan window, int capacity = 1024);
    public extern Func<LogProcessingEvent, string?> Key { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public TimeSpan Window { get; }
    public int Capacity { get; }
}
public sealed class LogEventChanges
{
    public string? Message { get; set; }
    public string? MessageTemplate { get; set; }
    public bool ClearMessageTemplate { get; set; }
    public IReadOnlyDictionary<string, LogValue>? Attributes { get; set; }
    public bool RemoveException { get; set; }
}
public sealed class LogProcessingEvent
{
    private LogProcessingEvent() { }
    public CoreLogLevel Level { get; }
    public System.Text.Json.JsonElement Record { get; }
    public extern string EventName { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern string Component { [MethodImpl(MethodImplOptions.InternalCall)] get; }
    public extern string Message { [MethodImpl(MethodImplOptions.InternalCall)] get; }
}

#nullable enable
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using CIS;
using CIS.Logging;

internal static class RuntimeConsumer
{
    public static async Task<LogStartResult> SafeStartup()
    {
        LogStartResult result = CoreLogRuntime.TryCreate(out CoreLogRuntime? runtime);
        if (result.Succeeded && runtime is not null)
        {
            _ = await runtime.StopAsync(CancellationToken.None);
            await runtime.DisposeAsync();
        }
        return result;
    }

    public static async Task Use(CancellationToken cancellationToken)
    {
        await using CoreLogRuntime runtime = CoreLogRuntime.Create();
        CoreLogger logger = runtime.CreateLogger(component: "Orders");
        var values = new Dictionary<string, LogValue> { ["order_id"] = LogValue.Integer(42) };
        int orderId = 42;
        _ = logger.Info($"Order {orderId:D4} accepted", values);
        _ = logger.Info(eventName: "order.accepted", message: $"Order {orderId} accepted", values: values);
        _ = logger.Write(CoreLogLevel.Warning, $"Order {orderId} will retry", context: new LogEventData { EventName = "order.retry" });
        bool enabled = logger.IsEnabled(level: CoreLogLevel.Information);
        using IDisposable scope = runtime.BeginScope(context: new OperationContextData { OperationId = "op-1" });
        LogWriteResult direct = logger.Write(level: CoreLogLevel.Information, data: new LogEventData { EventName = "order.created", Message = "Order created" });
        LogWriteResult deferred = logger.WriteLazy(level: CoreLogLevel.Information, factory: () => new LogEventData { EventName = "order.created", Message = "Order created" });
        _ = logger.Trace(message: "Message");
        _ = logger.Trace(eventName: "named.event", message: "Message");
        _ = logger.Trace(data: new LogEventData { EventName = "typed.event", Message = "Message" });
        _ = logger.TraceLazy(factory: () => new LogEventData { EventName = "lazy.event", Message = "Message" });
        _ = logger.Debug(message: "Message");
        _ = logger.Debug(eventName: "named.event", message: "Message");
        _ = logger.Debug(data: new LogEventData { EventName = "typed.event", Message = "Message" });
        _ = logger.DebugLazy(factory: () => new LogEventData { EventName = "lazy.event", Message = "Message" });
        _ = logger.Info(message: "Message");
        _ = logger.Info(eventName: "named.event", message: "Message");
        _ = logger.Info(data: new LogEventData { EventName = "typed.event", Message = "Message" });
        _ = logger.InfoLazy(factory: () => new LogEventData { EventName = "lazy.event", Message = "Message" });
        _ = logger.Warn(message: "Message");
        _ = logger.Warn(eventName: "named.event", message: "Message");
        _ = logger.Warn(data: new LogEventData { EventName = "typed.event", Message = "Message" });
        _ = logger.WarnLazy(factory: () => new LogEventData { EventName = "lazy.event", Message = "Message" });
        _ = logger.Error(message: "Message");
        _ = logger.Error(eventName: "named.event", message: "Message");
        _ = logger.Error(data: new LogEventData { EventName = "typed.event", Message = "Message" });
        _ = logger.ErrorLazy(factory: () => new LogEventData { EventName = "lazy.event", Message = "Message" });
        _ = logger.Critical(message: "Message");
        _ = logger.Critical(eventName: "named.event", message: "Message");
        _ = logger.Critical(data: new LogEventData { EventName = "typed.event", Message = "Message" });
        _ = logger.CriticalLazy(factory: () => new LogEventData { EventName = "lazy.event", Message = "Message" });
        LogFlushResult flush = await runtime.FlushAsync(timeout: TimeSpan.FromSeconds(1), cancellationToken: cancellationToken);
        LogStopResult stop = await runtime.StopAsync(cancellationToken: cancellationToken);
        CoreLogDiagnostics diagnostics = runtime.GetDiagnostics();
        IAsyncDisposable disposable = runtime;
        ValueTask disposal = disposable.DisposeAsync();
    }

    private static void ReadLogWriteResult(LogWriteResult value)
    {
        LogWriteOutcome readOutcome = value.Outcome;
        IReadOnlyList<LogOutputWriteResult> readOutputs = value.Outputs;
        string? readErrorCode = value.ErrorCode;
        bool readIsTruncated = value.IsTruncated;
    }

    private static void ReadLogOutputWriteResult(LogOutputWriteResult value)
    {
        string readOutputName = value.OutputName;
        LogOutputWriteStatus readStatus = value.Status;
        long? readAcceptedSequence = value.AcceptedSequence;
    }

    private static void ReadLogFlushResult(LogFlushResult value)
    {
        LogFrontendCaptureStatus capture = value.FrontendCaptureStatus;
        LogFrontendBatchSnapshot? batch = value.FrontendBatch;
        string? errorCode = value.ErrorCode;
        LogCompletion readCompletion = value.Completion;
        bool readSucceeded = value.Succeeded;
        bool readLossObserved = value.LossObserved;
        DateTimeOffset readBoundaryCapturedAtUtc = value.BoundaryCapturedAtUtc;
        DateTimeOffset readObservedAtUtc = value.ObservedAtUtc;
        long readInvalidEventCount = value.InvalidEventCount;
        long readTruncatedEventCount = value.TruncatedEventCount;
        IReadOnlyList<LogOutputDrainResult> readOutputs = value.Outputs;
    }

    private static void ReadLogStopResult(LogStopResult value)
    {
        string? errorCode = value.ErrorCode;
        LogCompletion readCompletion = value.Completion;
        bool readSucceeded = value.Succeeded;
        bool readLossObserved = value.LossObserved;
        DateTimeOffset readBoundaryCapturedAtUtc = value.BoundaryCapturedAtUtc;
        DateTimeOffset readObservedAtUtc = value.ObservedAtUtc;
        long readInvalidEventCount = value.InvalidEventCount;
        long readTruncatedEventCount = value.TruncatedEventCount;
        IReadOnlyList<LogOutputDrainResult> readOutputs = value.Outputs;
    }

    private static void ReadLogOutputDrainResult(LogOutputDrainResult value)
    {
        string readOutputName = value.OutputName;
        long readAcceptedSequenceBoundary = value.AcceptedSequenceBoundary;
        long readWritten = value.Written;
        long readFailed = value.Failed;
        long readAbandoned = value.Abandoned;
        long readPending = value.Pending;
        LogWriterFlushStatus readWriterFlushStatus = value.WriterFlushStatus;
        bool readWriterFlushSucceeded = value.WriterFlushSucceeded;
        LogOutputRejectionSnapshot readRejections = value.Rejections;
    }

    private static void ReadLogOutputRejectionSnapshot(LogOutputRejectionSnapshot value)
    {
        long readFiltered = value.Filtered;
        long readQueueFull = value.QueueFull;
        long readUnavailable = value.Unavailable;
    }

    private static void ReadCoreLogDiagnostics(CoreLogDiagnostics value)
    {
        CoreLogState readState = value.State;
        bool readAdmissionClosed = value.AdmissionClosed;
        DateTimeOffset readObservedAtUtc = value.ObservedAtUtc;
        DateTimeOffset? readShutdownStartedAtUtc = value.ShutdownStartedAtUtc;
        long readInvalidEventCount = value.InvalidEventCount;
        long readTruncatedEventCount = value.TruncatedEventCount;
        IReadOnlyList<LogOutputDiagnostics> readOutputs = value.Outputs;
        LogStopResult? readLastStopResult = value.LastStopResult;
    }

    private static void ReadLogOutputDiagnostics(LogOutputDiagnostics value)
    {
        string readOutputName = value.OutputName;
        LogOutputState readState = value.State;
        long readAcceptedSequence = value.AcceptedSequence;
        long readFiltered = value.Filtered;
        long readAdmissionAttempts = value.AdmissionAttempts;
        long readAccepted = value.Accepted;
        long readQueueFull = value.QueueFull;
        long readUnavailable = value.Unavailable;
        long readWritten = value.Written;
        long readFailed = value.Failed;
        long readAbandoned = value.Abandoned;
        long readPending = value.Pending;
        string? readLastFaultCode = value.LastFaultCode;
        DateTimeOffset? readLastFaultAtUtc = value.LastFaultAtUtc;
    }

    private static void ReadCoreLogInitializationException(CoreLogInitializationException value)
    {
        string readOutputName = value.OutputName;
        string readErrorCode = value.ErrorCode;
    }

    private static void NullCallPatterns(CoreLogger logger)
    {
        LogWriteResult direct = logger.Write(level: CoreLogLevel.None, data: null!);
        LogWriteResult deferred = logger.WriteLazy(level: CoreLogLevel.None, factory: null!);
        string error = LogErrorCodes.EnvelopeTooLarge;
        GC.KeepAlive(error);
    }
}

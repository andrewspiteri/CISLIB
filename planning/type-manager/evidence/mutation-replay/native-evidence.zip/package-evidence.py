"""Archive native evidence without adding duplicate source trees to graph extraction."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile
root=Path(sys.argv[1]).resolve()
repo=Path(sys.argv[2]).resolve()
out=Path(sys.argv[3]).resolve()
out.mkdir(parents=True,exist_ok=True)
aggregate=json.loads((root/'aggregate.json').read_text())
assert aggregate['complete'] and not aggregate['qualified']
entries={}
def add(path,name):
    if path.is_file():
        assert name not in entries,name
        entries[name]=path
def tree(path,prefix):
    for file in path.rglob('*'):
        if file.is_file():add(file,prefix+'/'+file.relative_to(path).as_posix())
for index in range(1,4):
    run=root/('shard-'+str(index))
    for name in ('results.json','audit.json'):add(run/name,'shard-'+str(index)+'/'+name)
    for folder in ('logs','tests','mutants'):tree(run/folder,'shard-'+str(index)+'/'+folder)
    for project in ('Core','Tests'):
        for file in (run/'source'/project/'obj').glob('*.json'):add(file,'shard-'+str(index)+'/restore/'+project+'/'+file.name)
    for file in (run/'source/Tests/bin/Release/net10.0').glob('CIS.Core*.dll'):add(file,'shard-'+str(index)+'/final-binaries/'+file.name)
for name in ('aggregate.json','shards.json','attempts.json','audit-replay.py','aggregate-shards.py','next-test-work.md','canonical-inputs.json','production-module-inputs.json','environment.json','package-evidence.py'):
    add(root/name,name)
for name in ('native-syntax-qualified-controls','parser-controls-final'):
    tree(root/name,name)
add(root/'parser-controls/run.py','parser-controls-final/run.py')
for file in (root/'syntax-helper').iterdir():
    if file.is_file():add(file,'syntax-helper/'+file.name)
for name in ('Helper.dll','Helper.runtimeconfig.json','Helper.deps.json'):
    add(root/'syntax-helper/bin/Release/net10.0'/name,'syntax-helper/bin/'+name)
for file in root.glob('*review*'):
    if file.is_file():add(file,'reviews/'+file.name)
for name in ('severity-control','syntax-negative'):
    for file in (root/name).iterdir():
        if file.is_file():add(file,'controls/'+name+'/'+file.name)
for name in ('pilot','ast-pilot','all-compile-errors','all-compile-errors-native','controlled-pilot','compile-errors-controlled','compile-errors-final','compile-errors-verified'):
    run=root/name
    add(run/'results.json','attempts/'+name+'/results.json')
    for folder in ('logs','tests'):tree(run/folder,'attempts/'+name+'/'+folder)
prepared=repo/'.artifacts/type-manager/mutation-query/prepared-closure'
add(prepared/'preparation.json','prepared/preparation.json')
tree(prepared/'source','prepared/source')
for file in ('eng/replay-type-manager-mutants.py','tests/fixtures/TypeManager/Mutation/ApplyNativeMutation.cs'):
    add(repo/'implementations/csharp'/file,'canonical/'+file)
manifest={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in sorted(entries.items())}
with zipfile.ZipFile(out/'native-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,path in sorted(entries.items()):archive.write(path,name)
    archive.writestr('archive-files.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'native-evidence.zip') as archive:
    assert archive.testzip() is None
    for name,expected in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==expected,name
(out/'archive-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'archiveSha256':hashlib.sha256((out/'native-evidence.zip').read_bytes()).hexdigest(),'bytes':(out/'native-evidence.zip').stat().st_size}))

"""Independently reconcile a completed replay with retained native reports."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
repo = Path(sys.argv[2]).resolve()
runner = repo / 'implementations/csharp/eng/replay-type-manager-mutants.py'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = json.loads((root / 'results.json').read_text())
assert report['complete'] and report['qualified'] is False
assert report['runnerSha256'] == digest(runner)
spec = importlib.util.spec_from_file_location('replay', runner)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
native_path = repo / 'planning/type-manager/evidence/mutation-query/strengthened/mutation-report.json'
assert digest(native_path) == report['nativeReportSha256']
native = json.loads(native_path.read_text())
expected = {str(m['id']) for f in native['files'].values() for m in f['mutants'] if m['status'] == 'CompileError'}
assert len(expected) == 238 and set(report['selectedIds']) <= expected
assert len(report['selectedIds']) == len(set(report['selectedIds']))
assert [x['id'] for x in report['results']] == report['selectedIds']
assert len(report['normalizedControls']) == 9
assert report['relaxedBaselineFiles'] == {p: report['baselineDeploymentFiles'][p] for p in ('CIS.Core.dll','CIS.Core.UnitTests.dll')}
assert all(c['passed'] == 90 and c['binarySha256'] == c['relaxedFiles']['CIS.Core.dll'] for c in report['normalizedControls'])
assert report['relaxedConfigurationAudit'] == {p: {'EditorConfigFiles': [], 'GlobalAnalyzerConfigFiles': []} for p in ('Core','Tests')}
identities = {(c['id'],c['name']) for c in report['baselineCases']}
assert len(identities) == 90
counts = collections.Counter()
for directory in (root / 'tests').iterdir():
    paths = list(directory.glob('*.trx'))
    assert len(paths) == 1, directory
    cases = module.native_cases(paths[0])
    assert {(c['id'],c['name']) for c in cases} == identities, directory
    assert len(cases) == 90 and all(c['outcome'] in ('Passed','Failed') for c in cases), directory
    counts['testRuns'] += 1
    counts['executedCases'] += len(cases)
    if directory.name in ('baseline','final') or directory.name.startswith('control-'):
        assert all(c['outcome'] == 'Passed' for c in cases), directory
for item in report['results']:
    evidence = root / 'mutants' / item['id']
    assert digest(evidence / item['file']) == item['sourceSha256'] == item['syntax']['sha256']
    if item['outcome'] == 'CompilationRejected':
        assert item['diagnostics'] and all(c.startswith('CS') for c in item['diagnostics'])
    elif item['outcome'] in ('Killed','Survived'):
        assert digest(evidence / 'CIS.Core.dll') == item['binarySha256']
        cases = module.native_cases(next((root / 'tests' / ('mutant-' + item['id'])).glob('*.trx')))
        failed = {c['name'] for c in cases if c['outcome'] == 'Failed'}
        assert failed == {c['name'] for c in item['failedTests']}
        if item['outcome'] == 'Killed':
            repeat = module.native_cases(next((root / 'tests' / ('mutant-' + item['id'] + '-repeat')).glob('*.trx')))
            assert failed and failed == {c['name'] for c in repeat if c['outcome'] == 'Failed'}
            assert item['repeatOutcome'] == 'Killed'
        else:
            assert not failed
    else:
        raise AssertionError('Needs separate audit: ' + item['outcome'])
summary = dict(collections.Counter(i['outcome'] for i in report['results']))
assert summary == report['summary']
result = dict(passed=True, qualified=False, reportSha256=digest(root / 'results.json'), variants=len(report['selectedIds']),
              normalizedControls=9, summary=summary, nativeCounts=dict(counts),
              strictPolicyRejected=sum(bool(i.get('strictPolicyRejected')) for i in report['results']),
              sourceFamilies=dict(collections.Counter(i['file'] for i in report['results'])))
(root / 'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

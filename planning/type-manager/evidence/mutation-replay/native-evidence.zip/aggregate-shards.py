import collections
import hashlib
import json
from pathlib import Path
import subprocess
import sys
root=Path(sys.argv[1]).resolve()
repo=Path(sys.argv[2]).resolve()
plan=json.loads((root/'shards.json').read_text())
reports=[]
all_ids=[]
for index,ids in enumerate(plan['ids'],1):
    path=root/('shard-'+str(index))
    subprocess.run([sys.executable,str(root/'audit-replay.py'),str(path),str(repo)],check=True)
    report=json.loads((path/'results.json').read_text())
    assert report['selectedIds']==ids
    reports.append(report)
    all_ids.extend(ids)
assert len(all_ids)==len(set(all_ids))==238
native=json.loads((repo/'planning/type-manager/evidence/mutation-query/strengthened/mutation-report.json').read_text())
assert set(all_ids)=={str(m['id']) for f in native['files'].values() for m in f['mutants'] if m['status']=='CompileError'}
for field in ('runnerSha256','preparationSha256','nativeReportSha256','syntaxManifestSha256'):
    assert len({r[field] for r in reports})==1
assert all({c['name'] for c in r['baselineCases']}=={c['name'] for c in reports[0]['baselineCases']} for r in reports)
mutants=[item for report in reports for item in report['results']]
mutants.sort(key=lambda i:int(i['id']))
result=dict(complete=True,qualified=False,scope='Three disjoint native Windows batches; original Stryker statuses remain immutable',
            variants=238,batches=[dict(index=i+1,variants=len(r['selectedIds']),summary=r['summary'],reportSha256=hashlib.sha256((root/('shard-'+str(i+1))/'results.json').read_bytes()).hexdigest()) for i,r in enumerate(reports)],
            summary=dict(collections.Counter(i['outcome'] for i in mutants)),
            strictPolicyRejected=sum(bool(i.get('strictPolicyRejected')) for i in mutants),
            runnerSha256=reports[0]['runnerSha256'],preparationSha256=reports[0]['preparationSha256'],
            nativeReportSha256=reports[0]['nativeReportSha256'],syntaxManifestSha256=reports[0]['syntaxManifestSha256'],
            normalizedControlRuns=sum(len(r['normalizedControls']) for r in reports),
            results=mutants)
(root/'aggregate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))

# Follow-on mutation work (not implemented or qualified)

- Add a direct diagnostic contract test for TypeManagerInitializationException:
  all typed context properties preserve exact values and original InnerException;
  a provided two-item loader-exception array is captured; modifying the caller array
  cannot alter the published read-only collection; null loader input yields zero
  entries. Assert message inclusion of all supplied context values, not arbitrary
  punctuation solely to kill string mutants. Replay the affected original IDs.
- Path validation survivors need native Linux analysis before equivalence claims.
  Colon and separator rules can differ by OS; a Windows-only replay is insufficient
  evidence of cross-platform unreachability. Preserve selected path diagnostics.
- Loader/default-context lookup mutants need fresh process cases, especially
  runtime binding substitution, same-name conflicts and dynamic/custom-context
  resolution. The 90-case source-module suite is not the existing process suite.
- Cancellation mutants must be related to the deterministic mid-load and final
  publication process/instrumented cases. ConfigureAwait(false)->true is not an
  automatic equivalent disposition; consider actual synchronization context and
  the caller-visible async contract.
- Equivalent/unreachable explanations remain per-mutant and reviewed. Neither
  compiler failure nor native SafeMode exclusion alone justifies a coverage claim.

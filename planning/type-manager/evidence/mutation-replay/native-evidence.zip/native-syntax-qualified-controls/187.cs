using System.Reflection;
using System.Runtime.Loader;

namespace CIS.TypeManagement;
internal sealed record PreparationInputs(Assembly HostAssembly, string ManifestPath, Type[] Contracts)
{
    internal static PreparationInputs Capture(TypeManagerOptions options)
    {
    }

    internal static void ValidateContract(Type contractType, string parameterName = "contractType")
    {
        ArgumentNullException.ThrowIfNull(contractType, parameterName);
        if (((((((((contractType.GetType() != typeof(object).GetType()) || ((!contractType.IsClass && !contractType.IsInterface))) || contractType.ContainsGenericParameters) || contractType.IsArray) || contractType.IsPointer) || contractType.IsByRef) || contractType.IsFunctionPointer) || !IsDefaultRuntimeType(contractType)))
        {
            throw new ArgumentException("Expected a closed runtime class or interface from the default loading context.", parameterName);
        }
    }

    private static bool IsDefaultRuntimeType(Type type)
    {
        if ((((type.GetType() != typeof(object).GetType()) || type.Assembly.IsDynamic) || (AssemblyLoadContext.GetLoadContext(type.Assembly) != AssemblyLoadContext.Default)))
        {
            return false;
        }

        if ((type.HasElementType && !IsDefaultRuntimeType(type.GetElementType()!)))
        {
            return false;
        }

        foreach (var argument in type.GenericTypeArguments)
        {
            if (!IsDefaultRuntimeType(argument))
            {
                return false;
            }
        }

        return true;
    }
}
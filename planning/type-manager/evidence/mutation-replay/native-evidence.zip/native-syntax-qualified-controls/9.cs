using System.Reflection;
using System.Text.Json;

namespace CIS.TypeManagement;
// Owned validated selections. No type loading, directory scanning or fallback discovery occurs here.
internal sealed class AssemblyInventory
{
    private AssemblyInventory(string manifestPath, IReadOnlyList<SelectedAssembly> assemblies)
    {
        ManifestPath = manifestPath;
        Assemblies = assemblies;
    }

    internal string ManifestPath { get; }
    internal IReadOnlyList<SelectedAssembly> Assemblies { get; }

    internal static async Task<AssemblyInventory> ReadAsync(string manifestPath, Assembly hostAssembly, CancellationToken cancellationToken)
    {
        byte[] bytes;
        try
        {
            bytes = await File.ReadAllBytesAsync(manifestPath, cancellationToken).ConfigureAwait(false);
        }
        catch (Exception error)when ((error is (IOException or UnauthorizedAccessException)))
        {
            throw Invalid(manifestPath, "The required assembly inventory could not be read.", error);
        }

        try
        {
        }
        catch (Exception error)when ((error is (((JsonException or FormatException) or ArgumentException) or InvalidOperationException)))
        {
            throw Invalid(manifestPath, ("The assembly inventory is invalid: " + error.Message), error);
        }
    }

    private static string ResolvePath(string directory, string relativePath)
    {
        if ((((Path.IsPathRooted(relativePath) || relativePath.Contains(':')) || relativePath.Contains('\\')) || relativePath.Split('/').Any(segment => (((segment.Length == 0) || (segment is ("." or ".."))) || ((OperatingSystem.IsWindows() && ((segment.EndsWith('.') || segment.EndsWith(' ')))))))))
        {
            throw new FormatException($"Expected a normalized relative assembly path: {relativePath}");
        }

        string path = Path.GetFullPath(relativePath, directory);
        string check = Path.GetRelativePath(directory, path);
        if (((Path.IsPathRooted(check) || (check == "..")) || check.StartsWith((".." + Path.DirectorySeparatorChar), StringComparison.Ordinal)))
        {
            throw new FormatException($"Selected assembly path escapes the inventory directory: {relativePath}");
        }

        return path;
    }

    private static string ReadString(JsonElement parent, string property)
    {
        if (((!parent.TryGetProperty(property, out var value) || (value.ValueKind != JsonValueKind.String)) || string.IsNullOrWhiteSpace(value.GetString())))
        {
            throw new FormatException($"Expected a nonblank string for {property}.");
        }

        return value.GetString()!;
    }

    private static void RequireKind(JsonElement value, JsonValueKind kind, string description)
    {
        if ((value.ValueKind != kind))
        {
            throw new FormatException($"Expected {description} to be {kind}.");
        }
    }

    private static void ValidateUniqueProperties(JsonElement value, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if ((value.ValueKind == JsonValueKind.Object))
        {
            var names = new HashSet<string>(StringComparer.Ordinal);
            foreach (var property in value.EnumerateObject())
            {
                if (!names.Add(property.Name))
                {
                    throw new FormatException($"Duplicate JSON property: {property.Name}");
                }

                ValidateUniqueProperties(property.Value, cancellationToken);
            }
        }
        else if ((value.ValueKind == JsonValueKind.Array))
        {
            foreach (var element in value.EnumerateArray())
            {
                ValidateUniqueProperties(element, cancellationToken);
            }
        }
        else if ((value.ValueKind == JsonValueKind.String))
        {
            // JsonDocument defers string decoding; unknown fields must still contain valid UTF-8/Unicode.
            _ = value.GetString();
        }
    }

    private static TypeManagerInitializationException Invalid(string manifestPath, string message, Exception inner, string? assetPath = null, string? assemblyIdentity = null)
    {
        return new TypeManagerInitializationException(TypeManagerFailureKind.InvalidInventory, message, inner, manifestPath: manifestPath, assetPath: assetPath, assemblyIdentity: assemblyIdentity);
    }
}

internal sealed record SelectedAssembly(string Identity, string SimpleName, string Path);
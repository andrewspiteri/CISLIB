from pathlib import Path
import json, hashlib, subprocess, xml.etree.ElementTree as ET
root=Path('.artifacts/type-manager/loader-coverage').resolve()
source=root/'source'; output=root/'audited-controls'; output.mkdir(exist_ok=False)
file=source/'Core/TypeManagement/SelectedAssemblyLoader.cs'; original=file.read_bytes()
syntax=Path('.artifacts/type-manager/mutation-replay/native-syntax-qualified-controls').resolve()
report=json.loads(Path('planning/type-manager/evidence/mutation-query/strengthened/mutation-report.json').read_text())
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label):
 folder=output/label; folder.mkdir(exist_ok=False)
 with (folder/'build.log').open('w') as log: code=subprocess.run(['dotnet','build','Tests/Tests.csproj','-c','Release','--no-incremental','-p:UseSharedCompilation=false'],cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
 if code: raise RuntimeError('Control build failed: '+label)
 dll=source/'Tests/bin/Release/net10.0/CIS.Core.UnitTests.dll'; core=dll.parent/'CIS.Core.dll'
 with (folder/'test.log').open('w') as log: code=subprocess.run(['dotnet','vstest',str(dll),'--logger:trx','--ResultsDirectory:'+str(folder)],cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
 trxs=list(folder.glob('*.trx')); assert len(trxs)==1; trx=trxs[0]; doc=ET.parse(trx); counters=doc.find('.//t:Counters',ns).attrib
 failed=[r.attrib['testName'] for r in doc.findall('.//t:UnitTestResult',ns) if r.attrib['outcome']!='Passed']
 if int(counters['total'])!=100: raise RuntimeError(counters)
 return dict(exitCode=code,counters=counters,failed=failed,coreSha256=sha(core),testSha256=sha(dll),sourceSha256=sha(file),trxSha256=sha(trx))
manifest_path=syntax/'manifest.json'
assert sha(manifest_path)=='a522a1a12a9a2c7457eb08b3f5c98c4ad8535352856512af1166fd2164d32546'
manifest=json.loads(manifest_path.read_text())
report_path=Path('planning/type-manager/evidence/mutation-query/strengthened/mutation-report.json')
assert sha(report_path)==manifest['nativeReportSha256']=='dfbca87cf2a1eb71bc00f8ea8016889a8ec9da65ab2f396b9b3fe97bd3842dcc'
prepared=json.loads((root/'final-prepared/preparation.json').read_text())
for relative, expected in prepared['inputs'].items():
 if relative.startswith(('Core/','Tests/')):
  assert sha(source/relative)==expected,relative
for canonical in Path('implementations/csharp/src/CIS.Core/TypeManagement').glob('*.cs'):
 assert sha(canonical)==sha(source/'Core/TypeManagement'/canonical.name)==manifest['sourceFiles'][canonical.name]
for relative in prepared['inputs']:
 if relative.startswith('Tests/'):
  matches=list(Path('implementations/csharp/tests').glob('CIS.Core.*/'+Path(relative).name))
  assert len(matches)==1 and sha(matches[0])==sha(source/relative),relative
native={m['id']:m for f in report['files'].values() for m in f['mutants']}
for id in ('282','290','335'):
 item=manifest['mutants'][id]
 assert item['file']=='SelectedAssemblyLoader.cs' and item['mutator']==native[id]['mutatorName']
 assert sha(syntax/(id+'.cs'))==item['sha256']
results={}
try:
 results['baseline']=run('baseline')
 assert results['baseline']['exitCode']==0 and not results['baseline']['failed']
 for id in ('282','290','335'):
  file.write_bytes((syntax/(id+'.cs')).read_bytes())
  results[id]=run('mutant-'+id)
  assert results[id]['exitCode']!=0 and results[id]['failed'],id
  if id=='282': assert results[id]['failed']==['ResolverSubstitutionMustMatchTheSelectedFullIdentity']
  if id=='335': assert results[id]['failed']==['ReferenceAttributeIsRejectedBeforeAnyNewLoad ("defined")']
  if id=='290':
   assert len(results[id]['failed'])==8
   assert 'NewPhysicalAssetIsPublishedAndThenReusedWithoutActivation' in results[id]['failed']
  assert results[id]['testSha256']==results['baseline']['testSha256']
finally:
 file.write_bytes(original)
 (output/'partial-results.json').write_text(json.dumps(results,indent=2)+'\n')
 results['restored']=run('restored')
 (output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert results['restored']['exitCode']==0 and not results['restored']['failed']
assert results['baseline']['coreSha256']==results['restored']['coreSha256']
assert results['baseline']['testSha256']==results['restored']['testSha256']
print(json.dumps(results,indent=2))

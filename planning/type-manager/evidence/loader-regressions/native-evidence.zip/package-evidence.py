from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
r=Path('.artifacts/type-manager/loader-coverage');out=Path('planning/type-manager/evidence/loader-regressions')
files={}
def add(p,key=None):
 if p.is_file():files[key or p.relative_to(r).as_posix()]=p
for d in ['final-developer-evidence','final-controls','audited-controls','controls','final-frozen-linux-results','frozen-linux-results','prepared/baseline','prepared/restored','prepared/mutation/reports']:
 for p in (r/d).rglob('*'):
  if p.suffix.lower() in ('.json','.log','.trx','.html'):add(p)
for d in ['frozen-windows','final-frozen-windows']:
 for p in (r/d).iterdir():
  if p.is_file():add(p)
 for p in (r/d/'results').glob('*.trx'):add(p)
for d in ['prepared','final-prepared']:
 prep=json.loads((r/d/'preparation.json').read_text());add(r/d/'preparation.json')
 for rel in prep['generatedFiles']:add(r/d/'source'/rel)
for p in r.iterdir():
 if p.is_file() and p.suffix.lower() in ('.json','.log','.txt','.py'):add(p)
for p in (r/'developer-format-failure').glob('*.json'):add(p)
add(r/'developer-format-failure/logs/format.log')
syntax=Path('.artifacts/type-manager/mutation-replay/native-syntax-qualified-controls')
for name in ['manifest.json','282.cs','290.cs','335.cs']:add(syntax/name,'syntax-provenance/'+name)
add(Path('planning/type-manager/evidence/mutation-query/strengthened/mutation-report.json'),'syntax-provenance/original-native-report.json')
for name in ['prepare-type-manager-mutation.py','verify-type-manager-runtime-tests.ps1']:add(Path('implementations/csharp/eng')/name,'final-tools/'+name)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=[]
with zipfile.ZipFile(out/'native-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for key,p in sorted(files.items()):
  b=p.read_bytes();z.writestr(key,b);manifest.append(dict(path=key,size=len(b),sha256=sha(b)))
with zipfile.ZipFile(out/'native-evidence.zip') as z:
 assert set(z.namelist())=={i['path'] for i in manifest}
 for i in manifest:assert sha(z.read(i['path']))==i['sha256']
(out/'archive-files.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
counts={}
for p in (r/'final-developer-evidence/families').glob('*/report.trx'):
 c=ET.parse(p).find('.//t:Counters',ns).attrib
 assert c['total']==c['passed'] and c['failed']=='0' and c['notExecuted']=='0'
 counts[p.parent.name]=int(c['total'])
assert sum(counts.values())==5041
j=json.loads((r/'final-developer-evidence/summary.json').read_text(encoding='utf-8-sig'))
c=json.loads((r/'audited-controls/results.json').read_text())
assert c['baseline']['coreSha256']==c['restored']['coreSha256']
checkpoint=dict(date='2026-10-14',qualified=False,productionChanged=False,frozenCoreSha256='d70fcfdc41b6d15829227f1cee60130ddad3f7f82cc11c7a2fcbf8d5f700fb09',frozenCasesPerOS=90,sourceModuleCases=100,nativeMutationRevision='Initial reviewed tests before final hardening; exact inputs archived',nativeMutation=dict(total=483,killed=109,survived=42,noCoverage=37,compileError=238,ignored=57,score=109/188*100,breakThreshold=90,exitCode=2),auditedControlIds=['282','290','335'],controlPlatform='Windows',developer=dict(runId=j['runId'],exitCode=j['exitCode'],stages=len(j['stages']),cases=counts,total=sum(counts.values()),scope='Combined working tree including uncommitted logging T03'),archive=dict(path='native-evidence.zip',sha256=sha((out/'native-evidence.zip').read_bytes()),files=len(manifest)),finalInputHashes=json.loads((r/'final-prepared/preparation.json').read_text())['inputs'])
(out/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Verified',len(manifest),'archive members;',round((out/'native-evidence.zip').stat().st_size/1024/1024,2),'MiB; Developer',sum(counts.values()))

from pathlib import Path
import json, hashlib, subprocess, xml.etree.ElementTree as ET
root=Path('.artifacts/type-manager/loader-coverage').resolve()
source=root/'source'; output=root/'controls'; output.mkdir(exist_ok=True)
file=source/'Core/TypeManagement/SelectedAssemblyLoader.cs'; original=file.read_bytes()
syntax=Path('.artifacts/type-manager/mutation-replay/native-syntax-qualified-controls').resolve()
report=json.loads(Path('planning/type-manager/evidence/mutation-query/strengthened/mutation-report.json').read_text())
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label):
 folder=output/label; folder.mkdir(exist_ok=True)
 with (folder/'build.log').open('w') as log: code=subprocess.run(['dotnet','build','Tests/Tests.csproj','-c','Release','--no-incremental','-p:UseSharedCompilation=false'],cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
 if code: raise RuntimeError('Control build failed: '+label)
 dll=source/'Tests/bin/Release/net10.0/CIS.Core.UnitTests.dll'; core=dll.parent/'CIS.Core.dll'
 with (folder/'test.log').open('w') as log: code=subprocess.run(['dotnet','vstest',str(dll),'--logger:trx','--ResultsDirectory:'+str(folder)],cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
 trx=next(folder.glob('*.trx')); doc=ET.parse(trx); counters=doc.find('.//t:Counters',ns).attrib
 failed=[r.attrib['testName'] for r in doc.findall('.//t:UnitTestResult',ns) if r.attrib['outcome']!='Passed']
 if int(counters['total'])!=100: raise RuntimeError(counters)
 return dict(exitCode=code,counters=counters,failed=failed,coreSha256=sha(core),testSha256=sha(dll),sourceSha256=sha(file),trxSha256=sha(trx))
results={}
try:
 results['baseline']=run('baseline')
 assert not results['baseline']['failed']
 for id in ('282','290','339'):
  file.write_bytes((syntax/(id+'.cs')).read_bytes())
  results[id]=run('mutant-'+id)
  assert results[id]['failed'],id
finally:
 file.write_bytes(original)
 results['restored']=run('restored')
 (output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert not results['restored']['failed']
assert results['baseline']['coreSha256']==results['restored']['coreSha256']
assert results['baseline']['testSha256']==results['restored']['testSha256']
print(json.dumps(results,indent=2))
